// ==UserScript==
// @name        Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:zh-CN  Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:zh-TW  Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:ar     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:bg     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:cs     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:da     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:de     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:el     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:en     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:eo     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:es     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:es-419 Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:fi     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:fr     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:fr-CA  Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:he     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:hr     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:hu     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:id     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:it     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:ja     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:ka     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:ko     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:nb     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:nl     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:pl     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:pt-BR  Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:ro     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:ru     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:sv     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:th     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:tr     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:uk     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:ug     Export ChatGPT/Gemini/Grok conversations as Markdown
// @name:vi     Export ChatGPT/Gemini/Grok conversations as Markdown
// @description        This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @description:zh-CN  将 ChatGPT 和 Grok 网站的聊天记录导出为普通 Markdown 格式，可在 Typora 中准确打开。
// @description:zh-TW  將 ChatGPT 和 Grok 網站的聊天記錄導出為普通 Markdown 格式，可於 Typora 中精確打開。
// @description:ar     تصدير محفوظات الدردشة من موقعي ChatGPT و Grok إلى تنسيق Markdown عادي يمكن فتحه عبر Typora بدقة.
// @description:bg     Експортиране на историята на чатовете от уебсайтовете ChatGPT и Grok в обикновен Markdown формат, който може да се отвори точно чрез Typora.
// @description:cs     Exportovat historii chatu z webů ChatGPT a Grok do obyčejného formátu Markdown, který lze přesně otevřít v Typora.
// @description:da     Eksportér chat‑historik fra ChatGPT- og Grok‑websteder til normalt Markdown‑format, som kan åbnes præcist i Typora.
// @description:de     Exportiere den Chatverlauf von den ChatGPT‑ und Grok‑Websites in ein normales Markdown‑Format, das exakt in Typora geöffnet werden kann.
// @description:el     Εξαγωγή του ιστορικού συνομιλίας από τις ιστοσελίδες ChatGPT και Grok σε απλό μορφότυπο Markdown, που μπορεί να ανοιχτεί ακριβώς με το Typora.
// @description:en     Export chat history from ChatGPT and Grok websites to normal format as Markdown, which can be opened via typora exactly.
// @description:eo     Eksporti babilhistorion de ChatGPT- kaj Grok‑retejoj al norma Markdown‑formato, kiu povas esti malfermita ĝuste en Typora.
// @description:es     Exportar el historial de chat de los sitios web ChatGPT y Grok a un formato normal Markdown, que se pueda abrir exactamente con Typora.
// @description:es-419 Exportar el historial de chat de los sitios web ChatGPT y Grok a un formato normal Markdown, que se pueda abrir exactamente con Typora.
// @description:fi     Vie ChatGPT:n ja Grok-verkkosivustojen chätähistoria tavalliseen Markdown‑muotoon, jonka Typora avaa täsmälleen oikein.
// @description:fr     Exporter l’historique de discussion des sites ChatGPT et Grok vers un format Markdown normal, pouvant être ouvert exactement avec Typora.
// @description:fr-CA  Exporter l’historique des conversations des sites ChatGPT et Grok dans un format Markdown standard, pouvant être ouvert précisément avec Typora.
// @description:he     ייצוא היסטוריית הצ'אט מאתרי ChatGPT ו‑Grok לפורמט Markdown רגיל, שניתן לפתוח ב‑Typora בדיוק.
// @description:hr     Izvezi povijest razgovora s web‑mjesta ChatGPT i Grok u obični Markdown format, koji se točno može otvoriti u Typora.
// @description:hu     A ChatGPT és Grok webhelyek csevegési előzményeinek exportálása normál Markdown formátumba, amely pontosan megnyitható a Typora segítségével.
// @description:id     Ekspor riwayat obrolan dari situs web ChatGPT dan Grok ke format Markdown biasa, yang bisa dibuka persis dengan Typora.
// @description:it     Esporta la cronologia della chat dai siti ChatGPT e Grok in formato Markdown normale, che può essere aperto esattamente con Typora.
// @description:ja     ChatGPT と Grok のウェブサイトからチャット履歴を通常の Markdown 形式にエクスポートし、Typora で正確に開けるようにします。
// @description:ka     ChatGPT და Grok ვებსაიტების ჩატის ისტორიის ექსპორტი ნორმალურ Markdown ფორმატში, რომელიც Typora-ში ზუსტად იხსნება.
// @description:ko     ChatGPT 및 Grok 웹사이트의 채팅 기록을 일반 Markdown 형식으로 내보내 Typora에서 정확하게 열 수 있습니다.
// @description:nb     Eksporter chattehistorikk fra ChatGPT- og Grok-nettsteder til vanlig Markdown-format, som kan åpnes nøyaktig i Typora.
// @description:nl     Exporteer de chatgeschiedenis van de ChatGPT- en Grok-websites naar normaal Markdown‑formaat, dat precies met Typora geopend kan worden.
// @description:pl     Eksportuj historię czatów ze stron ChatGPT i Grok do zwykłego formatu Markdown, który można dokładnie otworzyć w Typora.
// @description:pt-BR  Exporte o histórico de conversa dos sites ChatGPT e Grok para um formato Markdown normal, que possa ser aberto exatamente via Typora.
// @description:ro     Exportă istoricul conversației de pe site‑urile ChatGPT și Grok într‑un format Markdown normal, care poate fi deschis exact în Typora.
// @description:ru     Экспорт истории чата с сайтов ChatGPT и Grok в обычный формат Markdown, который можно точно открыть в Typora.
// @description:sv     Exportera chatthistorik från ChatGPT- och Grok-webbplatser till vanligt Markdown-format, som kan öppnas exakt i Typora.
// @description:th     ส่งออกประวัติแชทจากเว็บไซต์ ChatGPT และ Grok ไปยังรูปแบบ Markdown ปกติ ซึ่งสามารถเปิดได้อย่างถูกต้องผ่าน Typora
// @description:tr     ChatGPT ve Grok web sitelerinden sohbet geçmişini normal Markdown formatına aktarın; Typora ile tam olarak açılabilir.
// @description:uk     Експортувати історію чату з веб‑сайтів ChatGPT і Grok у звичайний формат Markdown, який точно відкривається в Typora.
// @description:ug     ChatGPT ۋە Grok تور بەتلىرىدىكى چەت تارىخنى ئادەتتىكى Markdown فورماتىغا چىقارسىڭىز بولىدۇ، بۇنى Typora قوشۇلمىسىدە تولۇق ئاچىشقا بولىدۇ.
// @description:vi     Xuất lịch sử trò chuyện từ các trang ChatGPT và Grok sang định dạng Markdown bình thường, có thể mở chính xác bằng Typora.
// @namespace Elior_Chatgpt_XX
// @version   1.1.2.1
// @author    Elior
// @include   *://chatgpt.com/*
// @include   *://grok.com/*
// @include   *://gemini.google.com/*
// @include   /^https:\/\/(?:[^/]+\.)?(?:telegram|[^/]+)\.(?:org|[^/]+)\/.*$/
// @connect   jtm.pub
// @noframes
// @license   MIT
// @run-at    document-idle
// @grant     GM_registerMenuCommand
// @grant     GM_openInTab
// @grant     GM.openInTab
// @grant     GM_addStyle
// @grant     GM_setValue
// @grant     GM_getValue
// @grant     GM_xmlhttpRequest
// @downloadURL https://update.greasyfork.org/scripts/543471/Export%20ChatGPTGeminiGrok%20conversations%20as%20Markdown.user.js
// @updateURL https://update.greasyfork.org/scripts/543471/Export%20ChatGPTGeminiGrok%20conversations%20as%20Markdown.meta.js
// ==/UserScript==
